# ScoreCard prototype VibeCoded

A Pen created on CodePen.

Original URL: [https://codepen.io/Garrity-McOsker/pen/dPbRevo](https://codepen.io/Garrity-McOsker/pen/dPbRevo).

